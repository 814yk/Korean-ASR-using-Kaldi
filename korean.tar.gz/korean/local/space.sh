#!/bin/bash
#
#	 온전한 data를 위해 space를 각 문서의 뒤에 붙여주는 프로그램
#	copyright 김상홍
#


if [ 0 == 1 ]; then
for src in Korean_1 Korean_2 Korean_3 Korean_4 Korean_5 Korean_6; do
	for source_dir in $(find -L $src -mindepth 1 -maxdepth 1 -type d | sort); do
		source=$(basename $source_dir)
		for f in ./$src/$source/*.txt; do
			echo $f
			sed 's/$/ /g' $f > tmp.txt
			sed 's/  / /g' tmp.txt > test.txt
			cat test.txt > $f
		done
	done
done
fi

for src in scripts; do
	for f in ./$src/*.txt; do
		echo $f
		sed 's/$/ /g' $f > tmp.txt
		sed 's/  / /g' tmp.txt > test.txt
		cat test.txt > $f
	done
done
