#!/bin/bash

src=$1
scripts=local/scripts

for source_dir in $(find -L $src -mindepth 1 -maxdepth 1 -type d | sort); do
	sub_dir=$(basename $source_dir)
	for data in $(find -L $src$sub_dir -mindepth 1 -maxdepth 1 -type d | sort); do
		dir=$(basename $data)
		for txt in $(find -L $scripts -mindepth 1 -maxdepth 1 -type f | sort); do
			cp $txt $1$sub_dir/$dir/$dir\_$(basename $txt)
		done
	done
done
